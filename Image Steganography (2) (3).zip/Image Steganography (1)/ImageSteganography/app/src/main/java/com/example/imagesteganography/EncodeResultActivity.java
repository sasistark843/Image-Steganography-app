package com.example.imagesteganography;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class EncodeResultActivity extends AppCompatActivity {

    Button btnSave;
    Button btnShr;
    ImageView img2;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encode_result);

        if (EncodeActivity.progressDialog.isShowing()) {
            EncodeActivity.progressDialog.dismiss();
        }

        btnSave = findViewById(R.id.btnSave);
        btnShr = findViewById(R.id.sharebtn);
        img2 = findViewById(R.id.img2);

        img2.setImageBitmap(G.enbmap);
        Bitmap imgBitmap = G.enbmap;

        btnSave.setOnClickListener(new View.OnClickListener() {
            Handler handler=new Handler(){

                @Override

                public void handleMessage(@NonNull Message msg) {

                    super.handleMessage(msg);

                    pd.incrementProgressBy(2);

                }

            };
            @Override
            public void onClick(View view) {
                pd=new ProgressDialog(EncodeResultActivity.this);
                pd.setMessage("Loading…");
                pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                pd.show();
                pd.setCancelable(false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            while(pd.getProgress()<=pd.getMax())
                            {
                                Thread.sleep(200);
                                handler.sendMessage(handler.obtainMessage());
                                if(pd.getProgress()==pd.getMax())
                                {
                                    pd.dismiss();
                                }
                            }
                        }catch (InterruptedException e){
                            e.printStackTrace();
                        }
                        Toast.makeText(EncodeResultActivity.this, "Image saved to Downloads", Toast.LENGTH_SHORT).show();
                    }
                }).start();
                OutputStream fOut;
                long currentTime = System.currentTimeMillis();
                File file = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS), "stegger-" + currentTime + ".png"); // the File to save ,
                try {
                    fOut = new FileOutputStream(file);
                    imgBitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut); // saving the Bitmap to a file,,
                    fOut.flush(); // Not really required
                    fOut.close(); // do not forget to close the stream
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        ImageButton backbtn1 = (ImageButton) findViewById(R.id.backbtn);
        backbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(EncodeResultActivity.this, EncodeActivity.class);
                startActivity(intent2);
            }
        });
        ImageButton btn1 = findViewById(R.id.overflowbtn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(EncodeResultActivity.this, btn1);
                popupMenu.getMenuInflater().inflate(R.menu.menu4, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem Item) {
                        switch (Item.getItemId()) {
                            case R.id.encode_button:
                                Intent intent = new Intent(EncodeResultActivity.this, EncodeActivity.class);
                                startActivity(intent);
                                return true;
                            case R.id.home_button:
                                Intent intent1 = new Intent(EncodeResultActivity.this, Home.class);
                                startActivity(intent1);
                                return true;
                            case R.id.guide:
                                Intent intent2 = new Intent(EncodeResultActivity.this, GuideActivity.class);
                                startActivity(intent2);
                                return true;
                            case R.id.decode_button:
                                Intent intent3 = new Intent(EncodeResultActivity.this, DecodeActivity.class);
                                startActivity(intent3);
                                return true;
                            case R.id.menua:
                                Intent intent4 = new Intent(EncodeResultActivity.this,MenuActivity.class);
                                startActivity(intent4);
                        }
                        return true;
                    }
                });
                popupMenu.show();

            }
        });
        btnShr.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("image/jpeg");

                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.TITLE, "title");
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);


                OutputStream outstream;
                try {
                    outstream = getContentResolver().openOutputStream(uri);
                    G.enbmap.compress(Bitmap.CompressFormat.PNG, 100, outstream);
                    outstream.close();
                } catch (Exception e) {
                }

                share.putExtra(Intent.EXTRA_STREAM, uri);
                startActivity(Intent.createChooser(share, "Share Image"));
            }
        });
        ImageButton backbtn = (ImageButton) findViewById(R.id.backbtn);
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(EncodeResultActivity.this, EncodeActivity.class);
                startActivity(intent2);
            }
        });
    }
}