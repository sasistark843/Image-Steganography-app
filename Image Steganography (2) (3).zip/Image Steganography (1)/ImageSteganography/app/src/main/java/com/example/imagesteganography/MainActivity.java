package com.example.imagesteganography;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    TextView gotoLogin;
    EditText Email,pass,phoneno,usern;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    String s3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        gotoLogin = findViewById(R.id.gotologin);
        gotoLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),Login.class);
                startActivity(intent);
            }
        });
        mAuth = FirebaseAuth.getInstance();
        Email = findViewById(R.id.email);
        pass = findViewById(R.id.password);
        phoneno=findViewById(R.id.phoneno);
        usern=findViewById(R.id.fullname);

        Button btn = findViewById(R.id.Register);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);

                builder.setTitle("Register")

                        .setMessage("Are you sure?")

                        .setCancelable(false)

                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                            @Override

                            public void onClick(DialogInterface dialogInterface, int i) {
                                String s1 = Email.getText().toString();
                                String s2 = pass.getText().toString();
                                s3= usern.getText().toString();
                                String s4=phoneno.getText().toString();
                                writeUser(s3,s2,s1,s4);
                                createAccount();
                            }

                        })

                        .setNegativeButton("No", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                AlertDialog dialog= builder.create();
                dialog.show();
            }
        });
        mDatabase = FirebaseDatabase.getInstance().getReference();
    }
    private void writeUser(String username,String password,String email,String phonenumber){
        User user = new User(username,password,email,phonenumber);
        mDatabase.child("User").child(username).setValue(user);
    }
    private void createAccount(){
        String email = Email.getText().toString();
        String password = pass.getText().toString();
        if(TextUtils.isEmpty(email)){
            Email.setError("Email cannot be empty");
            Email.requestFocus();
        }
        else if(TextUtils.isEmpty(password)){
            pass.setError("Password cannot be Empty");
            pass.requestFocus();
        }
        else {
            mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(MainActivity.this,"email and password Registered",Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, Login.class);
                        intent.putExtra("username", s3); // pass the username as an extra
                        // pass the username as an extra
                        startActivity(intent);

                    }
                    else
                    {
                        Toast.makeText(MainActivity.this,"Registration failed",Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

}