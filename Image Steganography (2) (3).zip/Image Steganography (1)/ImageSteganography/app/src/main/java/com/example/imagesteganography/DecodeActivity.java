package com.example.imagesteganography;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

public class DecodeActivity extends AppCompatActivity {

    Intent intent;
    Button btnSelectSteg;
    Button btnDecodeSteg;
    ImageView stegImg;
    public static ProgressDialog progressDialog;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decode);

        btnSelectSteg = findViewById(R.id.btnSelectSteg);
        btnDecodeSteg = findViewById(R.id.btnDecodeSteg);
        stegImg = findViewById(R.id.stegImg);

        btnSelectSteg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                progressDialog = new ProgressDialog(DecodeActivity.this);
                progressDialog.setMessage("Please wait"); // Setting Message
                progressDialog.setTitle("opening files"); // Setting Title
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                progressDialog.show(); // Display Progress Dialog
                progressDialog.setCancelable(false);
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            Thread.sleep(400);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        progressDialog.dismiss();
                    }
                }).start();
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 1);
            }
        });
        ImageButton btn1 = findViewById(R.id.overflowbtn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(DecodeActivity.this, btn1);
                popupMenu.getMenuInflater().inflate(R.menu.menu3, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem Item) {
                        switch (Item.getItemId()) {
                            case R.id.encode_button:
                                Intent intent = new Intent(DecodeActivity.this, EncodeActivity.class);
                                startActivity(intent);
                                return true;
                            case R.id.home_button:
                                Intent intent1 = new Intent(DecodeActivity.this, Home.class);
                                startActivity(intent1);
                                return true;
                            case R.id.guide:
                                Intent intent2 = new Intent(DecodeActivity.this,GuideActivity.class);
                                startActivity(intent2);
                                return true;
                            case R.id.menua:
                                Intent intent3 = new Intent(DecodeActivity.this,MenuActivity.class);
                                startActivity(intent3);
                        }
                        return true;
                    }
                });
                popupMenu.show();

            }
        });

        btnDecodeSteg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder=new AlertDialog.Builder(DecodeActivity.this);

                builder.setTitle("Decode")

                        .setMessage("Are you sure?")

                        .setCancelable(false)

                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                            @Override

                            public void onClick(DialogInterface dialogInterface, int i) {
                                if(stegImg.getTag().toString().equals("default"))
                                    Toast.makeText(DecodeActivity.this, "Please select an image", Toast.LENGTH_SHORT).show();
                                else {
                                    progressDialog = new ProgressDialog(DecodeActivity.this);
                                    progressDialog.setMessage("Please wait"); // Setting Message
                                    progressDialog.setTitle("Decoding"); // Setting Title
                                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                                    progressDialog.show(); // Display Progress Dialog
                                    progressDialog.setCancelable(false);
                                    G.msgDecoded = "";
                                    G.decode();
                                    openDecodeResultActivity();
                                }

                            }

                        })

                        .setNegativeButton("No", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                AlertDialog dialog= builder.create();
                dialog.show();
            }
        });
        ImageButton backbtn = (ImageButton) findViewById(R.id.backbtn);
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(DecodeActivity.this,Home.class);
                startActivity(intent2);
            }
        });
    }

    public void openDecodeResultActivity(){
        Handler handler=new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                intent = new Intent(DecodeActivity.this,DecodeResultActivity.class);
                startActivity(intent);
            }
        },2500);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
        if (resultCode == RESULT_OK && requestCode == 1) {
            Uri selectedImage = imageReturnedIntent.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                bitmap = Bitmap.createScaledBitmap(bitmap, 450, 600, true);
                stegImg.setImageBitmap(bitmap);
                G.debmap = bitmap;
                stegImg.setTag("updated");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}