package com.example.imagesteganography;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;

public class Aboutus extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aboutus);
        ImageButton btn1 = findViewById(R.id.overflowbtn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(Aboutus.this, btn1);
                popupMenu.getMenuInflater().inflate(R.menu.menu4, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem Item) {
                        switch (Item.getItemId()) {
                            case R.id.encode_button:
                                Intent intent = new Intent(Aboutus.this, EncodeActivity.class);
                                startActivity(intent);
                                return true;
                            case R.id.home_button:
                                Intent intent1 = new Intent(Aboutus.this, Home.class);
                                startActivity(intent1);
                                return true;
                            case R.id.guide:
                                Intent intent2 = new Intent(Aboutus.this,GuideActivity.class);
                                startActivity(intent2);
                                return true;
                            case R.id.decode_button:
                                Intent intent3 = new Intent(Aboutus.this, DecodeActivity.class);
                                startActivity(intent3);
                                return true;
                            case R.id.menua:
                                Intent intent4 = new Intent(Aboutus.this,MenuActivity.class);
                                startActivity(intent4);
                        }
                        return true;
                    }
                });
                popupMenu.show();

            }
        });
        ImageButton backbtn1 = (ImageButton) findViewById(R.id.backbtn);
        backbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(Aboutus.this,DecodeActivity.class);
                startActivity(intent2);
            }
        });
    }
}