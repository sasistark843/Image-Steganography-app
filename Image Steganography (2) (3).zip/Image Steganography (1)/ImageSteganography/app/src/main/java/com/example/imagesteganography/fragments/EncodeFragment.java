package com.example.imagesteganography.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;

import com.example.imagesteganography.EncodeActivity;
import com.example.imagesteganography.R;

public class EncodeFragment extends Fragment {
Button bt;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_encode, container, false);
        bt=v.findViewById(R.id.btnEnc);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(getActivity(), EncodeActivity.class);
                startActivity(intent);
            }
        });
        return v;
    }
}