package com.example.imagesteganography;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class GuideActivity extends AppCompatActivity {
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);
        ImageButton backbtn1 = (ImageButton) findViewById(R.id.backbtn);
        backbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(GuideActivity.this,Home.class);
                startActivity(intent2);
            }
        });
        ImageButton btn1 = (ImageButton) findViewById(R.id.overflowbtn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(GuideActivity.this, btn1);
                popupMenu.getMenuInflater().inflate(R.menu.menu5, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem Item) {
                        switch (Item.getItemId()) {
                            case R.id.encode_button:
                                Intent intent = new Intent(GuideActivity.this, EncodeActivity.class);
                                startActivity(intent);
                                return true;
                            case R.id.home_button:
                                Intent intent1 = new Intent(GuideActivity.this, Home.class);
                                startActivity(intent1);
                                return true;
                            case R.id.decode_button:
                                Intent intent2 = new Intent(GuideActivity.this,DecodeActivity.class);
                                startActivity(intent2);
                                return true;
                        }
                        return true;
                    }
                });
                popupMenu.show();

            }
        });
    }
}