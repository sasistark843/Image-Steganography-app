package com.example.imagesteganography;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;

import androidx.appcompat.app.AppCompatActivity;

public class imgDisplay extends AppCompatActivity {
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_img_display);
         ImageButton back = (ImageButton) findViewById(R.id.backbtn);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(imgDisplay.this,Home.class);
                startActivity(intent);
            }
        });
        ImageButton btn1 = findViewById(R.id.overflowbtn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(imgDisplay.this, btn1);
                popupMenu.getMenuInflater().inflate(R.menu.menu4, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem Item) {
                        switch (Item.getItemId()) {
                            case R.id.encode_button:
                                Intent intent = new Intent(imgDisplay.this, EncodeActivity.class);
                                startActivity(intent);
                                return true;
                            case R.id.home_button:
                                Intent intent1 = new Intent(imgDisplay.this, Home.class);
                                startActivity(intent1);
                                return true;
                            case R.id.guide:
                                Intent intent2 = new Intent(imgDisplay.this,GuideActivity.class);
                                startActivity(intent2);
                                return true;
                            case R.id.decode_button:
                                Intent intent3 = new Intent(imgDisplay.this, DecodeActivity.class);
                                startActivity(intent3);
                                return true;
                            case R.id.menua:
                                Intent intent4 = new Intent(imgDisplay.this,MenuActivity.class);
                                startActivity(intent4);
                        }
                        return true;
                    }
                });
                popupMenu.show();

            }
        });
    }
}