package com.example.imagesteganography;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;

public class MenuActivity extends AppCompatActivity {
    TabLayout tabLayout;
    ViewPager2 viewPager2;
    MyViewPagerAdapter myViewPagerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        tabLayout=findViewById(R.id.tb_layout);
        viewPager2=findViewById(R.id.view_pager);
        myViewPagerAdapter=new MyViewPagerAdapter(this);
        viewPager2.setAdapter(myViewPagerAdapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                tabLayout.getTabAt(position).select();
            }
        });
        ImageButton btn1 = (ImageButton) findViewById(R.id.overflowbtn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                PopupMenu popupMenu = new PopupMenu(MenuActivity.this, btn1);
                popupMenu.getMenuInflater().inflate(R.menu.menu5, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem Item) {
                        switch (Item.getItemId()) {
                            case R.id.encode_button:
                                Intent intent = new Intent(MenuActivity.this, EncodeActivity.class);
                                startActivity(intent);
                                return true;
                            case R.id.home_button:
                                Intent intent1 = new Intent(MenuActivity.this, Home.class);
                                startActivity(intent1);
                                return true;
                            case R.id.decode_button:
                                Intent intent2 = new Intent(MenuActivity.this,DecodeActivity.class);
                                startActivity(intent2);
                                return true;
                        }
                        return true;
                    }
                });
                popupMenu.show();

            }
        });
ImageButton btn2 = (ImageButton) findViewById(R.id.backbtn);
btn2.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent intent= new Intent(MenuActivity.this,Home.class);
        startActivity(intent);
    }
});

    }
}