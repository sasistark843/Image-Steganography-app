package com.example.imagesteganography;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;



public class Login extends AppCompatActivity {
    TextView gotoRegister;
    EditText email1;
    EditText pass1;
    Button login;
    FirebaseAuth mAuth;
    String userid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Intent intent = getIntent();
        userid = intent.getStringExtra("username");

        mAuth = FirebaseAuth.getInstance();
        gotoRegister = findViewById(R.id.gotoRegister);
        gotoRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Login.this,MainActivity.class);
                startActivity(i);
            }
        });
        login = findViewById(R.id.LoginBtn);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder=new AlertDialog.Builder(Login.this);

                builder.setTitle("Login")

                        .setMessage("Are you sure?")

                        .setCancelable(false)

                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                            @Override

                            public void onClick(DialogInterface dialogInterface, int i) {

                              signin();

                            }

                        })

                        .setNegativeButton("No", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                AlertDialog dialog= builder.create();
                dialog.show();
            }
        });
        email1 = findViewById(R.id.loginemail);
        pass1 = findViewById(R.id.loginpassword);
    }
    private  void signin(){
        String email = email1.getText().toString();
        String password = pass1.getText().toString();
        if(TextUtils.isEmpty(email)){
            email1.setError("Email cannot be empty");
            email1.requestFocus();
        }
        else if(TextUtils.isEmpty(password)){
            pass1.setError("Password cannot be Empty");
            pass1.requestFocus();
        }
        else {
            mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(Login.this,"login successful",Toast.LENGTH_SHORT).show();
                        //startActivity(new Intent(Login.this,Home.class));
                        Intent i=new Intent(Login.this, Home.class);
                        i.putExtra("username",userid);
                        startActivity(i);
                    }
                    else
                    {
                        Toast.makeText(Login.this,"login failed",Toast.LENGTH_SHORT).show();
                        clearing();
                    }
                }
            });
        }

    }
    private void clearing(){
        email1.setText("");
        pass1.setText("");
    }
}
