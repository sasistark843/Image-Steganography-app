package com.example.imagesteganography.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;

import com.example.imagesteganography.DecodeActivity;
import com.example.imagesteganography.R;


public class DecodeFragment extends Fragment {
    Button bt;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.fragment_decode, container, false);
        bt=v.findViewById(R.id.btnDec);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(getActivity(), DecodeActivity.class);
                startActivity(intent);
            }
        });
        return v;
    }


}