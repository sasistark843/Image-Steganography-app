package com.example.imagesteganography;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

public class DecodeResultActivity extends AppCompatActivity {

    public static boolean passwordFound;
    TextView secretMsg;
    Button menu;

    Button btnGet;
    EditText pass;
    public static ProgressDialog progressDialog;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decode_result);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "My Notification";
            String description = "My notification description";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel chnnelID = new NotificationChannel("Notification", "My notification", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            chnnelID.setDescription(description);
            manager.createNotificationChannel(chnnelID);
        }

        if (DecodeActivity.progressDialog.isShowing()) {
            DecodeActivity.progressDialog.dismiss();
        }

        secretMsg = findViewById(R.id.textView3);
        menu = findViewById(R.id.btnMenu);

        btnGet = findViewById(R.id.btnGetMsg);
        pass = findViewById(R.id.PassDecode);

        if(passwordFound)
        {
            pass.setVisibility(View.VISIBLE);
            btnGet.setVisibility(View.VISIBLE);
        }
        else
        {
            secretMsg.setText(G.msgDecoded);
        }
        ImageButton btn1 = findViewById(R.id.overflowbtn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(DecodeResultActivity.this, btn1);
                popupMenu.getMenuInflater().inflate(R.menu.menu4, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem Item) {
                        switch (Item.getItemId()) {
                            case R.id.encode_button:
                                Intent intent = new Intent(DecodeResultActivity.this, EncodeActivity.class);
                                startActivity(intent);
                                return true;
                            case R.id.home_button:
                                Intent intent1 = new Intent(DecodeResultActivity.this, Home.class);
                                startActivity(intent1);
                                return true;
                            case R.id.guide:
                                Intent intent2 = new Intent(DecodeResultActivity.this,GuideActivity.class);
                                startActivity(intent2);
                                return true;
                            case R.id.decode_button:
                                Intent intent3 = new Intent(DecodeResultActivity.this, DecodeActivity.class);
                                startActivity(intent3);
                                return true;
                            case R.id.menua:
                                Intent intent4 = new Intent(DecodeResultActivity.this,MenuActivity.class);
                                startActivity(intent4);
                        }
                        return true;
                    }
                });
                popupMenu.show();

            }
        });
        ImageButton backbtn1 = (ImageButton) findViewById(R.id.backbtn);
        backbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(DecodeResultActivity.this,DecodeActivity.class);
                startActivity(intent2);
            }
        });
        btnGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder=new AlertDialog.Builder(DecodeResultActivity.this);

                builder.setTitle("Decode")

                        .setMessage("Are you sure?")

                        .setCancelable(false)

                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                            @Override

                            public void onClick(DialogInterface dialogInterface, int i) {
                                if(pass.getText().toString().equals(G.decodePassword)){
                                    progressDialog = new ProgressDialog(DecodeResultActivity.this);
                                    progressDialog.setMessage("Please wait"); // Setting Message
                                    progressDialog.setTitle("opening files"); // Setting Title
                                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                                    progressDialog.show(); // Display Progress Dialog
                                    progressDialog.setCancelable(false);
                                    new Thread(new Runnable() {
                                        public void run() {
                                            try {
                                                Thread.sleep(400);
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                            progressDialog.dismiss();
                                        }
                                    }).start();
                                    secretMsg.setText(G.msgDecoded);
                                    NotificationCompat.Builder builder=new NotificationCompat.Builder(DecodeResultActivity.this,"Notification")
                                            .setSmallIcon(R.drawable.logo)
                                            .setContentTitle("Decode Notification")
                                            .setContentText("Your secret message is decrypted from image")
                                            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                                            .setAutoCancel(true);
                                    Intent in = new Intent(DecodeResultActivity.this,DecodeResultActivity.class);
                                    in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    PendingIntent p=PendingIntent.getActivity(DecodeResultActivity.this,0,in,PendingIntent.FLAG_UPDATE_CURRENT);
                                    builder.setContentIntent(p);
                                    NotificationManager manager=(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                                    manager.notify(1, builder.build());
                                }
                                else{
                                    pass.setError("Password doesn't match");
                                }

                            }

                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                AlertDialog dialog= builder.create();
                dialog.show();
            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMenu();
            }
        });
        ImageButton backbtn = (ImageButton) findViewById(R.id.backbtn);
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(DecodeResultActivity.this,DecodeActivity.class);
                startActivity(intent2);
            }
        });
    }
    public void openMenu()
    {
        Intent intent = new Intent(this,MenuActivity.class);
        startActivity(intent);
    }


}