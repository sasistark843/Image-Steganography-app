package com.example.imagesteganography;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class Profile extends AppCompatActivity {

    TextView e1, e2, e3;
    String username, email, phonenumber, userid;
    //private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_profile);

        Intent intent = getIntent();
        userid = intent.getStringExtra("username");

        e1 = findViewById(R.id.usern);
        e2 = findViewById(R.id.email);
        e3 = findViewById(R.id.phone);

        DatabaseReference fdb = FirebaseDatabase.getInstance().getReferenceFromUrl("https://image-steganography-4cb42-default-rtdb.firebaseio.com/");

        //if (user != null) {
            //String userId = user.getUid();
            fdb.child("User").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    // Retrieve data from snapshot
                    username = snapshot.child(userid).child("username").getValue(String.class);
                    email = snapshot.child(userid).child("email").getValue(String.class);
                    phonenumber = snapshot.child(userid).child("phonenumer").getValue(String.class);

                    // Update TextViews with retrieved data
                    e1.setText(username);
                    e2.setText(email);
                    e3.setText(phonenumber);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Handle error
                }
            });
        //}
    }
}
