package com.example.imagesteganography;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.google.android.material.navigation.NavigationView;

public class Home extends AppCompatActivity {

    String userid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Intent intent = getIntent();
        userid = intent.getStringExtra("username");

        Button logoutbtn = (Button) findViewById(R.id.logoutbtn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Home.this,MenuActivity.class);
                startActivity(intent);
            }
        });
        Button workflow = (Button) findViewById(R.id.workfl);
        workflow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Home.this,imgDisplay.class);
                startActivity(intent1);
            }
        });
        ImageButton btn1 = findViewById(R.id.overflowbtn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(Home.this, btn1);
                popupMenu.getMenuInflater().inflate(R.menu.menu1, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem Item) {
                        switch (Item.getItemId()) {
                            case R.id.encode_button:
                                Intent intent = new Intent(Home.this, EncodeActivity.class);
                                startActivity(intent);
                                return true;
                            case R.id.decode_button:
                                Intent intent1 = new Intent(Home.this, DecodeActivity.class);
                                startActivity(intent1);
                                return true;
                            case R.id.guide:
                                Intent intent2 = new Intent(Home.this,GuideActivity.class);
                                startActivity(intent2);
                                return true;
                            case R.id.menua:
                                Intent intent4 = new Intent(Home.this,MenuActivity.class);
                                startActivity(intent4);
                        }
                        return true;
                    }
                });
                popupMenu.show();

            }
        });
        final DrawerLayout drawerlayout = findViewById(R.id.drawerlayout);

        findViewById(R.id.menubtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerlayout.openDrawer(GravityCompat.START);
                findViewById(R.id.menuDecode).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent3 = new Intent(Home.this,DecodeActivity.class);
                        startActivity(intent3);
                    }
                });
                findViewById(R.id.menuencode).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent4 = new Intent(Home.this,EncodeActivity.class);
                        startActivity(intent4);
                    }
                });
                findViewById(R.id.menuguide).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent5 = new Intent(Home.this,GuideActivity.class);
                        startActivity(intent5);
                    }
                });
                findViewById(R.id.menuAboutus).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent6 = new Intent(Home.this,MenuActivity.class);
                        startActivity(intent6);
                    }
                });
                findViewById(R.id.logout).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent7 = new Intent(Home.this,Login.class);
                        startActivity(intent7);
                    }
                });
                findViewById(R.id.menuProfile).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent8 = new Intent(Home.this,Profile.class);
                        intent8.putExtra("username",userid);
                        startActivity(intent8);

                    }
                });
                findViewById(R.id.menuSettings).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent9 = new Intent(Home.this,Aboutus.class);
                        startActivity(intent9);
                    }
                });
            }
        });
        NavigationView navigationView =findViewById(R.id.navigationview);
        navigationView.setItemIconTintList(null);

        NavController navController = Navigation.findNavController(this,R.id.NavHostFragment);
    }
}